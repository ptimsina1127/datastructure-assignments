| Deliverable         |                                                       Points | Comments |
|---------------------|-------------------------------------------------------------:|----------|
| Tests               | ![Points badge](../../blob/badges/.github/badges/points.svg) |          |
| Commits             |                                                            5 |          |
| Commenting          |                                                            5 |          |
| Answer to Questions |                                                           15 |          |
| **Total**           |                                                              |          |
| **Bonus Total**     |                                                              |          |


## Questions

| Question     | Comment |
|--------------|---------|
| **1. (3pt)** |         | 
| Add          |         |
| Remove       |         |
| Contains     |         |
| **2. (4pt)** |         | 
| Union        |         | 
| Intersection |         | 
| Difference   |         | 
| Assignment   |         | 
| **3. (1pt)** |         | 
| **4. (1pt)** |         | 
| **5. (4pt)** |         | 
