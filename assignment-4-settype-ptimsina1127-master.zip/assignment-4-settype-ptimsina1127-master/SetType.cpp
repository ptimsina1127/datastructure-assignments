#include <string>
#include <iostream>
#include "SetType.h"

using namespace std;

template<class T>
SetType<T>::SetType() {
    // Create an array of forward_lists and initially set to an empty forward_list
    buckets = new forward_list<T>[DEFAULT_BUCKETS];
    numBuckets = DEFAULT_BUCKETS;
    numElems = 0;
    maxLoad = DEFAULT_LOAD_FACTOR;
    currBucket = 0;
    iterCount = 0;
    // Your code here
}

template<class T>
SetType<T>::SetType(SetType &otherSet) {
    // This should make use of copySet
    copySet(otherSet);
}

template<class T>
SetType<T>::~SetType() {
    delete [] buckets;
}


template<class T>
SetType<T> SetType<T>::operator+(T elem) {
    SetType<T> result;

    // Your code here

    return result;
}

template<class T>
SetType<T> SetType<T>::operator-(T elem) {
    SetType<T> result;

    // Your code here

    return result;
}

template<class T>
SetType<T> SetType<T>::operator+(SetType& otherSet) {
    SetType<T> result;

    // Your code here

    return result;
}

template<class T>
SetType<T> SetType<T>::operator*(SetType& otherSet) {
    SetType<T> result;

    // Your code here

    return result;
}

template<class T>
SetType<T> SetType<T>::operator-(SetType& otherSet) {
    SetType<T> result;

    // Your code here

    return result;
}

template<class T>
T SetType<T>::GetNextItem() {
    // Returns the current item and then move to the next item
    T item;

    // Your code here

    return item;
}

template<class T>
int SetType<T>::GetHashIndex(const T& key) {
    // This is done... No touching!
    unordered_map<T,T> mapper;
    typename unordered_map<T,T>::hasher hashFunction = mapper.hash_function();
    return static_cast<int>(hashFunction(key) % numBuckets);
}


template<class T>
void SetType<T>::SetMaxLoad(double max) {
    // This function is done
    if (max < 0.1)
        maxLoad = 0.1;
    else
        maxLoad = max;
}

template<class T>
SetType<T>& SetType<T>::operator=(SetType const &other) {

    // Your code here

    return *this;
}


template<class T>
void SetType<T>::Rehash(int newNumBuckets) {
    SetType<T> rehashedSet(newNumBuckets);

    // Your code here

    *this = rehashedSet;
}
template<class T>
SetType<T>::SetType(int numBucks) {
    buckets = new forward_list<T>[numBucks];
    this->numBuckets = numBucks;
    numElems = 0;
    maxLoad = DEFAULT_LOAD_FACTOR;
    currBucket = 0;
    iterCount = 0;
}

template<class T>
void SetType<T>::Add(T elem) {
    if(Contains(elem))
    {
        return;
    }

    // How to figure out the bucket an element, should go into
    int bucket = GetHashIndex(elem);
    buckets[bucket].push_front(elem);
    numElems++;

    // If the load factor exceeds the max load.
    if(LoadFactor() > maxLoad)
    {
        // Double the number of the buckets.
        int new_numBuckets = numBuckets * 2;

        // Call the rehash function.
        Rehash(new_numBuckets);
    }
}

template<class T>
void SetType<T>::Remove(T elem) {
    if(!(Contains(elem)))
    {
        return;
    }
     // {1, 2, 3, 4, 5}
     // delete 3
     // {1, 2, 4, 5}
    // Get the index.
    int bucket = GetHashIndex(elem);
    // this denotes the value or position before the beginning.
    // On above example it points to the position before 1.
    prev = buckets[bucket].before_begin();
    // beginning of mylist
    for (it = buckets[bucket].begin(); it != buckets[bucket].end(); ++it) // Go through the whole bucket.
    {
        if(*it == elem) // If you find the elem.
        {
            numElems--; // decrement the num elems.
            // delete the item.
            buckets[bucket].erase_after(prev);
            // return.
            return;
        }
        prev = it;
    }
}

template<class T>
bool SetType<T>::Contains(T elem) {
    // Get the index.
    int bucket = GetHashIndex(elem);

    // beginning of mylist
    for (it = buckets[bucket].begin(); it != buckets[bucket].end(); ++it) // Go through the whole bucket.
    {
        if(*it == elem) // If you find the elem.
        {
            return true; // return true.
        }
    }
    return false; // else false.
}

template<class T>
void SetType<T>::MakeEmpty() {

}

template<class T>
double SetType<T>::LoadFactor() const {
    return 0;
}

template<class T>
void SetType<T>::ResetIterator() {

}

template<class T>
void SetType<T>::copySet(const SetType &otherSet) {

}

// A = {1, 2, 3, 4}
// B = {2, 3, 7, 8}
// A U B = {1,2,3,4,7,8}
// A intersection B = {2,3}
// A + B = union
// A * B = intersection

