These are sample solutions for the assignment.  They work for mac and windows machines.
