#include "Box.h"

/*
 * Function: Default constructor.
 * precondition: None.
 * post condition: Initializes all values to 0.
 *
*/
Box::Box() {
    //Initialize the dimension of the box to zero
    width =0;
    height=0;
    length=0;
}
/*
 * Function: Sets width,height and length of the box.
 * precondition: Height,Width,and length should be positive number
 * post condition: The function sets the value.
 *
*/
Box::Box(int width, int height, int length) {
    //Set the dimensions of the box using provided values
    setWidth(width);
    setHeight(height);
    setLength(length);

}
/*
 * Function: Returns Width
 * precondition: None.
 * post condition: Width is returned.
 *
*/
double Box::getWidth() const {
    //return the width of the box
    return width;
}
/*
 * Function: Set Width.
 * precondition: Width should be a valid number.
 * post condition: The width of the box is set.
 *
*/
void Box::setWidth(double width) {
    if (width<0){
        throw "Negative Dimension";
    }
    this->width=width;
}
/*
 * Function: Returns Height
 * precondition: None.
 * post condition: The height of the box is returned.
 *
*/
double Box::getHeight() const {
    return height;
}
/*
 * Function: Sets Height
 * precondition: Height Should be a valid number
 * post condition: The Height of the box is set.
 *
*/
void Box::setHeight(double height) {
    if (height<0){
        throw "Negative Dimension";
    }
    this->height=height;
}
/*
 * Function: Returns length
 * precondition: None.
 * post condition: The length of the box is returned.
 *
*/
double Box::getLength() const {
    return length;
}
/*
 * Function: Sets Length.
 * precondition: Length should be a valid number.
 * post condition: The length of a box is set.
 *
*/
void Box::setLength(double length) {
    //validate and set the length of the box
    if (length<0){
        throw "Negative Dimension";
    }
    this->length=length;
}


/* Function: Calculate and return the surface area of the box
 * Precondition: None
 * Post-condition: The surface area of the box is returned.
 */
double Box::getSurfaceArea() const {
    return 2*(width*length+width*height+height*length);
}
/*
 * Function: Calculate and return the volume of the box.
 * precondition: None.
 * post condition: Volume of the box is returned.
 *
*/
double Box::getVolume() const {
    return width*height*length;
}
/*
 * Function: resizes the dimension
 * precondition: The argument factor should be passed.
 * post condition: Dimensions are resized by the factor.
 *
*/
void Box::resize(double factor) {

    //resize the box dimensions by applying the given factor to each dimension
    setWidth(factor*width);
    setHeight(factor*height);
    setLength(factor*length);
}

