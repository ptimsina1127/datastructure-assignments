| Deliverable          | Points | Comments |
| -------------------- | ------:| ---------|
| Constructor_Test     |  3     | |
| Getters_Setters_Test |  4     | |
| Volume_Area_Test     |  2     | |
| Commits              |  1     | |
| Commenting           |  5     | |
| Answer to Questions  |  25    | |
| **Total**            | **39** | |

# Questions

3 You should look at the member variables of the class -1
